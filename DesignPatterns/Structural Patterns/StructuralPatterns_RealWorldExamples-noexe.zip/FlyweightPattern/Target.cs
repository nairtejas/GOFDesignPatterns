﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FlyweightPattern.FlyweightBase;

namespace FlyweightPattern
{
    public class Target
    {
        public Unit UnitData;
        public Guid ID;
    }
}
